Never finished this fully, probably missing some animations and stuff. I would appreciate if you credit my YouTube channel if you use this https://www.youtube.com/channel/UCeJTvm9mynoKXstinGlWsYQ

